from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from django.contrib import auth
from django.template.context_processors import csrf

#logs a user in
def login(request):
	c = {}
	c.update(csrf(request))
	return render_to_response('login-tab.html', c)
	
#authenticates a users information logs in if required
def auth_view(request):
	username = request.POST.get('username', '')
	password = request.POST.get('password', '')
	user = auth.authenticate(username=username, password=password)
	
	if user is not None:
		auth.login(request, user)
		return HttpResponseRedirect('/search/')
	else:
		return HttpResponseRedirect("/")

#defines if the user is logged in or not		
def loggedin(request):
	return render_to_response('inventory/search.html', {'full_name': request.user})
	
#if the login fails to authenticate do this
def invalid_login(request):
	return render_to_response('invalid_login.html')

#if user successfully registers do this
def register_success(request):
	return render_to_response('index.html')